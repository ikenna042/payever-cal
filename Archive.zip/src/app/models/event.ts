export interface EventModel {
    name: string;
    date:   Date;
}